# Sprint 1 Feature Prototype

This React prototype covers the acceptance criteria for the three Sprint 1 feature stories assigned on the Team 12 board:

- **F-013 — View Aptitude Tests**
- **F-014 — Attempt Timed Aptitude Tests**
- **F-017 — Placement Preparation Resources**

## Run locally

Requirements: Node.js 20.19+ (or Node.js 22+) and npm.

1. Open a terminal in the `client` folder.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the local URL printed by Vite (usually `http://localhost:5173`).

## What's implemented

- Aptitude test listings show title, description, duration and availability.
- Unavailable tests cannot be started. An empty-state preview is included for QA.
- Timed multiple-choice attempts support changing answers, early submission, automatic submission at zero, score calculation and saving attempts in browser local storage.
- A QA demo timer mode is available to validate auto-submission quickly.
- Preparation resources are grouped by category and include an unavailable-link example with explanatory feedback.

## Important limitations

This is a **front-end prototype** because the repository had no application source structure when inspected. It uses seeded sample data and browser `localStorage`; it is not connected to a Node/Express API, database, login/roles, or server-side evaluation. Those integrations must be agreed and implemented before treating the stories as production-complete or merging the prototype into the team application. Do not mark an issue Done solely because this prototype exists; verify it against the team's agreed architecture and acceptance criteria.
